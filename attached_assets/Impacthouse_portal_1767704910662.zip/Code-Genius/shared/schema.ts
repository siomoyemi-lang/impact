import { pgTable, text, serial, integer, boolean, timestamp, date, uuid, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Import Auth Tables
export * from "./models/auth";
import { users } from "./models/auth";

// === TABLE DEFINITIONS ===

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  grade: text("grade").notNull(),
  parentId: varchar("parent_id").references(() => users.id).notNull(), // Links to the parent (user)
  createdAt: timestamp("created_at").defaultNow(),
});

export const bills = pgTable("bills", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => students.id), // Nullable for class-wide bills
  description: text("description").notNull(),
  amount: integer("amount").notNull(), // Stored in cents
  dueDate: timestamp("due_date").notNull(),
  status: text("status", { enum: ["pending", "paid"] }).default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  targetGrade: text("target_grade"), // Added for class-wide bills
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  billId: integer("bill_id").references(() => bills.id).notNull(),
  amount: integer("amount").notNull(), // Stored in cents
  receiptUrl: text("receipt_url"), // URL from object storage
  status: text("status", { enum: ["pending", "verified", "rejected"] }).default("pending").notNull(),
  paymentDate: timestamp("payment_date").defaultNow(),
  verifiedBy: varchar("verified_by").references(() => users.id), // Admin who verified
  notes: text("notes"),
});

// === RELATIONS ===

export const usersRelations = relations(users, ({ many }) => ({
  students: many(students), // Parent has many students
}));

export const studentsRelations = relations(students, ({ one, many }) => ({
  parent: one(users, {
    fields: [students.parentId],
    references: [users.id],
  }),
  bills: many(bills),
}));

export const billsRelations = relations(bills, ({ one, many }) => ({
  student: one(students, {
    fields: [bills.studentId],
    references: [students.id],
  }),
  payments: many(payments),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  bill: one(bills, {
    fields: [payments.billId],
    references: [bills.id],
  }),
  verifier: one(users, {
    fields: [payments.verifiedBy],
    references: [users.id],
  }),
}));

// === BASE SCHEMAS ===

export const insertStudentSchema = createInsertSchema(students).omit({ id: true, createdAt: true });
export const insertBillSchema = createInsertSchema(bills).omit({ id: true, createdAt: true, status: true }).extend({
  billType: z.enum(["individual", "class"]).default("individual"),
});
export const insertPaymentSchema = createInsertSchema(payments).omit({ id: true, paymentDate: true, status: true, verifiedBy: true });

// === EXPLICIT API CONTRACT TYPES ===

export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;

export type Bill = typeof bills.$inferSelect;
export type InsertBill = z.infer<typeof insertBillSchema>;

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

export type CreateStudentRequest = InsertStudent;
export type CreateBillRequest = InsertBill;
export type CreatePaymentRequest = InsertPayment; // Receipt URL comes from frontend upload flow

// Admin verification
export type VerifyPaymentRequest = {
  status: "verified" | "rejected";
  notes?: string;
};

// Joined types for frontend display
export type BillWithStudent = Bill & { student: Student };
export type PaymentWithBill = Payment & { bill: Bill & { student: Student } };
