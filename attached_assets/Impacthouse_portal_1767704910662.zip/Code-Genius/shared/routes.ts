import { z } from 'zod';
import { insertStudentSchema, insertBillSchema, insertPaymentSchema, students, bills, payments } from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  students: {
    list: {
      method: 'GET' as const,
      path: '/api/students', // Parents see their wards, Admins see all? Or maybe /api/my-students for parents
      responses: {
        200: z.array(z.custom<typeof students.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/students', // Admin only
      input: insertStudentSchema,
      responses: {
        201: z.custom<typeof students.$inferSelect>(),
        400: errorSchemas.validation,
        403: errorSchemas.unauthorized,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/students/:id',
      responses: {
        200: z.custom<typeof students.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    getBills: {
      method: 'GET' as const,
      path: '/api/students/:id/bills',
      responses: {
        200: z.array(z.custom<typeof bills.$inferSelect>()),
      },
    },
  },
  bills: {
    create: {
      method: 'POST' as const,
      path: '/api/bills', // Admin only
      input: insertBillSchema,
      responses: {
        201: z.custom<typeof bills.$inferSelect>(),
        400: errorSchemas.validation,
        403: errorSchemas.unauthorized,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/bills', // Admin sees all?
      responses: {
        200: z.array(z.custom<typeof bills.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/bills/:id',
      responses: {
        200: z.custom<typeof bills.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  payments: {
    create: {
      method: 'POST' as const,
      path: '/api/payments', // Parents upload receipt
      input: insertPaymentSchema,
      responses: {
        201: z.custom<typeof payments.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    listPending: {
      method: 'GET' as const,
      path: '/api/payments/pending', // Admin only
      responses: {
        200: z.array(z.custom<typeof payments.$inferSelect>()), // Should probably include relations
      },
    },
    verify: {
      method: 'POST' as const,
      path: '/api/payments/:id/verify', // Admin only
      input: z.object({
        status: z.enum(["verified", "rejected"]),
        notes: z.string().optional(),
      }),
      responses: {
        200: z.custom<typeof payments.$inferSelect>(),
        400: errorSchemas.validation,
        403: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
  },
};

// ============================================
// REQUIRED: buildUrl helper
// ============================================
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
