import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { registerObjectStorageRoutes } from "./replit_integrations/object_storage";
import { seed } from "./seed";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Seed Data
  await seed();
  
  // Register Integrations
  await setupAuth(app);
  registerAuthRoutes(app);
  registerObjectStorageRoutes(app);

  // === Students ===

  app.get(api.students.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const user = req.user as any;
    if (user.role === "admin") {
      const students = await storage.getAllStudents();
      return res.json(students);
    } else {
      const students = await storage.getStudentsByParent(user.id);
      return res.json(students);
    }
  });

  app.post(api.students.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as any;
    if (user.role !== "admin") return res.status(403).json({ message: "Admin access required" });

    try {
      const input = api.students.create.input.parse(req.body);
      
      // Ensure the parent exists (or create a placeholder)
      let parent = await storage.getUser(input.parentId);
      if (!parent) {
        // Create placeholder user if they haven't logged in yet
        parent = await storage.createPlaceholderUser(input.parentId);
      }
      
      const student = await storage.createStudent(input);
      res.status(201).json(student);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.get(api.students.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const student = await storage.getStudent(Number(req.params.id));
    if (!student) return res.sendStatus(404);
    res.json(student);
  });

  app.get(api.students.getBills.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const bills = await storage.getBillsByStudent(Number(req.params.id));
    res.json(bills);
  });

  // === Bills ===

  app.get(api.bills.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const bills = await storage.getAllBills();
    res.json(bills);
  });

  app.post(api.bills.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as any;
    const adminEmails = ["admin@example.com", "principal@impacthouse.edu"];
    if (!adminEmails.includes(user.email || "")) return res.status(403).json({ message: "Admin access required" });

    try {
      const input = api.bills.create.input.parse(req.body);
      
      if (req.body.billType === "class" && req.body.targetGrade) {
        const bills = await storage.createClassBills({
          ...input,
          targetGrade: req.body.targetGrade
        });
        return res.status(201).json(bills[0] || { message: "No students found in this grade" });
      }

      const bill = await storage.createBill(input);
      res.status(201).json(bill);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  // === Payments ===

  app.post(api.payments.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.payments.create.input.parse(req.body);
      const payment = await storage.createPayment(input);
      res.status(201).json(payment);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.get(api.payments.listPending.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as any;
    const adminEmails = ["admin@example.com", "principal@impacthouse.edu"];
    if (!adminEmails.includes(user.email || "")) return res.status(403).json({ message: "Admin access required" });

    const payments = await storage.getPendingPayments();
    res.json(payments);
  });

  app.post(api.payments.verify.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as any;
    const adminEmails = ["admin@example.com", "principal@impacthouse.edu"];
    if (!adminEmails.includes(user.email || "")) return res.status(403).json({ message: "Admin access required" });

    try {
      const { status, notes } = api.payments.verify.input.parse(req.body);
      const payment = await storage.updatePaymentStatus(Number(req.params.id), status, user.id, notes);
      if (!payment) return res.sendStatus(404);
      res.json(payment);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  return httpServer;
}
