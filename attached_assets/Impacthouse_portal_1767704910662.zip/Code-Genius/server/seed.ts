import { storage } from "./storage";
import { authStorage } from "./replit_integrations/auth/storage";
import { users, students, bills, payments } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export async function seed() {
  const existingUsers = await storage.getAllUsers();
  if (existingUsers.length > 0) return;

  console.log("Seeding database...");

  // 1. Create Users (Handled by Replit Auth usually, but we need them for FKs)
  // We can insert some dummy users if Replit Auth table allows it, 
  // OR we just wait for real users. 
  // BUT, we need a parent to link students to. 
  // Let's create a dummy parent and admin.
  // Note: Replit Auth users have string IDs (usually UUIDs from the provider).
  // We'll generate some.

  const parentUser = await authStorage.upsertUser({
    id: "parent-1",
    email: "parent@example.com",
    firstName: "John",
    lastName: "Doe",
    profileImageUrl: "https://ui-avatars.com/api/?name=John+Doe"
  } as any); // Type cast if needed, or use the auth storage method

  const adminUser = await authStorage.upsertUser({
    id: "admin-1",
    email: "admin@example.com",
    firstName: "Admin",
    lastName: "User",
    profileImageUrl: "https://ui-avatars.com/api/?name=Admin+User"
  } as any);

  // 2. Create Students
  const student1 = await storage.createStudent({
    name: "Alice Doe",
    grade: "10th Grade",
    parentId: parentUser.id
  });

  const student2 = await storage.createStudent({
    name: "Bob Doe",
    grade: "8th Grade",
    parentId: parentUser.id
  });

  // 3. Create Bills
  const bill1 = await storage.createBill({
    studentId: student1.id,
    description: "Tuition Fee - Term 1",
    amount: 500000, // $5000.00
    dueDate: new Date("2024-12-31"),
  });

  const bill2 = await storage.createBill({
    studentId: student2.id,
    description: "Library Fee",
    amount: 5000, // $50.00
    dueDate: new Date("2024-11-30"),
  });

  // 4. Create Payments
  await storage.createPayment({
    billId: bill1.id,
    amount: 250000, // Partial payment
    receiptUrl: "https://placehold.co/600x400/png",
    notes: "Part payment via bank transfer",
  });

  console.log("Seeding complete!");
}
