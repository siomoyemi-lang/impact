import { 
  users, students, bills, payments,
  type User,
  type Student, type InsertStudent,
  type Bill, type InsertBill,
  type Payment, type InsertPayment
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Users (Basic ops, auth handles the rest)
  getUser(id: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>; // For admin to select parents
  createPlaceholderUser(email: string): Promise<User>;

  // Students
  createStudent(student: InsertStudent): Promise<Student>;
  getStudent(id: number): Promise<Student | undefined>;
  getStudentsByParent(parentId: string): Promise<Student[]>;
  getAllStudents(): Promise<Student[]>;

  // Bills
  createBill(bill: InsertBill): Promise<Bill>;
  createClassBills(billData: InsertBill & { targetGrade: string }): Promise<Bill[]>;
  getBillsByStudent(studentId: number): Promise<Bill[]>;
  getBill(id: number): Promise<Bill | undefined>;
  getAllBills(): Promise<Bill[]>;

  // Payments
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPendingPayments(): Promise<Payment[]>;
  updatePaymentStatus(id: number, status: "verified" | "rejected", verifiedBy: string, notes?: string): Promise<Payment | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createPlaceholderUser(email: string): Promise<User> {
    const [user] = await db.insert(users).values({
      id: email, // Using email as ID for placeholders
      email,
      firstName: "Parent",
      lastName: "(Placeholder)",
      role: "parent",
    }).returning();
    return user;
  }

  async updateUserRole(userId: string, role: "admin" | "parent"): Promise<User | undefined> {
    const [user] = await db.update(users).set({ role }).where(eq(users.id, userId)).returning();
    return user;
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const [student] = await db.insert(students).values(insertStudent).returning();
    return student;
  }

  async getStudent(id: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student;
  }

  async getStudentsByParent(parentId: string): Promise<Student[]> {
    return await db.select().from(students).where(eq(students.parentId, parentId));
  }

  async getAllStudents(): Promise<Student[]> {
    return await db.select().from(students);
  }

  async createBill(insertBill: InsertBill): Promise<Bill> {
    const [bill] = await db.insert(bills).values(insertBill).returning();
    return bill;
  }

  async createClassBills(billData: InsertBill & { targetGrade: string }): Promise<Bill[]> {
    const studentsInGrade = await db.select().from(students).where(eq(students.grade, billData.targetGrade));
    
    if (studentsInGrade.length === 0) return [];

    const billRecords = studentsInGrade.map(student => ({
      studentId: student.id,
      description: billData.description,
      amount: billData.amount,
      dueDate: billData.dueDate,
      targetGrade: billData.targetGrade,
    }));

    return await db.insert(bills).values(billRecords).returning();
  }

  async getBillsByStudent(studentId: number): Promise<Bill[]> {
    return await db.select().from(bills).where(eq(bills.studentId, studentId)).orderBy(desc(bills.createdAt));
  }

  async getBill(id: number): Promise<Bill | undefined> {
    const [bill] = await db.select().from(bills).where(eq(bills.id, id));
    return bill;
  }

  async getAllBills(): Promise<Bill[]> {
    return await db.select().from(bills).orderBy(desc(bills.createdAt));
  }

  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const [payment] = await db.insert(payments).values(insertPayment).returning();
    return payment;
  }

  async getPendingPayments(): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.status, "pending")).orderBy(desc(payments.paymentDate));
  }

  async updatePaymentStatus(id: number, status: "verified" | "rejected", verifiedBy: string, notes?: string): Promise<Payment | undefined> {
    const [payment] = await db
      .update(payments)
      .set({ status, verifiedBy, notes })
      .where(eq(payments.id, id))
      .returning();
    return payment;
  }
}

export const storage = new DatabaseStorage();
