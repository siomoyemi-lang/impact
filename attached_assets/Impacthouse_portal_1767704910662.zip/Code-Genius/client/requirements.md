## Packages
date-fns | For date formatting
framer-motion | For smooth animations and transitions
lucide-react | Icons (already in base but good to be explicit)
recharts | For admin dashboard charts (optional but nice)
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
- Images for receipts are handled via Object Storage (Uploader component provided).
- Auth is handled via Replit Auth (useAuth hook provided).
- API routes are defined in shared/routes.ts and must be matched exactly.
