import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertStudent, type Student, type Bill } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useStudents() {
  return useQuery<Student[]>({
    queryKey: [api.students.list.path],
    queryFn: async () => {
      const res = await fetch(api.students.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch students");
      const data = await res.json();
      return api.students.list.responses[200].parse(data);
    },
  });
}

export function useStudent(id: number) {
  return useQuery<Student>({
    queryKey: [api.students.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.students.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch student details");
      const data = await res.json();
      return api.students.get.responses[200].parse(data);
    },
    enabled: !!id,
  });
}

export function useStudentBills(id: number) {
  return useQuery<Bill[]>({
    queryKey: [api.students.getBills.path, id],
    queryFn: async () => {
      const url = buildUrl(api.students.getBills.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch student bills");
      const data = await res.json();
      return api.students.getBills.responses[200].parse(data);
    },
    enabled: !!id,
  });
}

export function useCreateStudent() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (studentData: InsertStudent) => {
      const res = await fetch(api.students.create.path, {
        method: api.students.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(studentData),
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create student");
      }

      const data = await res.json();
      return api.students.create.responses[201].parse(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.students.list.path] });
      toast({
        title: "Success",
        description: "Student created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
