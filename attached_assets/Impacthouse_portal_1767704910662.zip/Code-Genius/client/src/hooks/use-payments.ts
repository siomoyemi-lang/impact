import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertPayment, type Payment } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function usePendingPayments() {
  return useQuery<Payment[]>({
    queryKey: [api.payments.listPending.path],
    queryFn: async () => {
      const res = await fetch(api.payments.listPending.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch pending payments");
      const data = await res.json();
      return api.payments.listPending.responses[200].parse(data);
    },
  });
}

export function useCreatePayment() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (paymentData: InsertPayment) => {
       const payload = {
        ...paymentData,
        amount: Number(paymentData.amount),
        billId: Number(paymentData.billId),
      };

      const res = await fetch(api.payments.create.path, {
        method: api.payments.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to submit payment");
      }

      const data = await res.json();
      return api.payments.create.responses[201].parse(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.students.getBills.path] }); // Refresh bills list
      toast({
        title: "Payment Submitted",
        description: "Your receipt has been uploaded and is pending verification.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useVerifyPayment() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, status, notes }: { id: number, status: "verified" | "rejected", notes?: string }) => {
      const url = buildUrl(api.payments.verify.path, { id });
      const res = await fetch(url, {
        method: api.payments.verify.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, notes }),
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to verify payment");
      }

      const data = await res.json();
      return api.payments.verify.responses[200].parse(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.payments.listPending.path] });
      toast({
        title: "Success",
        description: "Payment status updated",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
