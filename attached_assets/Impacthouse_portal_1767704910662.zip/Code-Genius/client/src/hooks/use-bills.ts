import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertBill, type Bill } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useBills() {
  return useQuery<Bill[]>({
    queryKey: [api.bills.list.path],
    queryFn: async () => {
      const res = await fetch(api.bills.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch bills");
      const data = await res.json();
      return api.bills.list.responses[200].parse(data);
    },
  });
}

export function useBill(id: number) {
  return useQuery<Bill>({
    queryKey: [api.bills.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.bills.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch bill details");
      const data = await res.json();
      return api.bills.get.responses[200].parse(data);
    },
    enabled: !!id,
  });
}

export function useCreateBill() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (billData: InsertBill) => {
      // Ensure amount is number (zod coerce handles it, but good practice)
      const payload = {
        ...billData,
        amount: Number(billData.amount),
        studentId: Number(billData.studentId),
      };

      const res = await fetch(api.bills.create.path, {
        method: api.bills.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create bill");
      }

      const data = await res.json();
      return api.bills.create.responses[201].parse(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.bills.list.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/students"] }); // Invalidate potential student bill lists
      toast({
        title: "Success",
        description: "Bill issued successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
