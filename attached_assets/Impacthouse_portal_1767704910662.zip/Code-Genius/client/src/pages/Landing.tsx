import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  GraduationCap, 
  ShieldCheck, 
  Users, 
  ArrowRight, 
  CheckCircle2,
  CreditCard
} from "lucide-react";

export default function Landing() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  // If user is already logged in, show dashboard selection
  if (user) {
    const isAdmin = user.role === "admin";

    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-muted/20 p-4">
        <div className="max-w-2xl w-full text-center space-y-8">
          <div className="space-y-2">
            <h1 className="text-4xl font-display font-bold text-foreground">Welcome back, {user.firstName}!</h1>
            <p className="text-muted-foreground text-lg">Select your dashboard to continue.</p>
          </div>

          <div className={`grid gap-6 ${isAdmin ? "md:grid-cols-2" : "max-w-md mx-auto"}`}>
            <Link href="/parent/wards">
              <div className="group relative bg-card hover:border-primary/50 transition-all duration-300 border rounded-2xl p-8 text-left shadow-lg hover:shadow-xl hover:-translate-y-1 cursor-pointer h-full">
                <div className="h-14 w-14 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Users className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">Parent Dashboard</h3>
                <p className="text-muted-foreground">View your wards, check bills, and make payments securely.</p>
                <div className="absolute bottom-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity transform translate-x-2 group-hover:translate-x-0">
                  <ArrowRight className="w-6 h-6 text-primary" />
                </div>
              </div>
            </Link>

            {isAdmin ? (
              <Link href="/admin/students">
                <div className="group relative bg-card hover:border-accent/50 transition-all duration-300 border rounded-2xl p-8 text-left shadow-lg hover:shadow-xl hover:-translate-y-1 cursor-pointer h-full">
                  <div className="h-14 w-14 rounded-2xl bg-purple-100 text-purple-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <ShieldCheck className="w-7 h-7" />
                  </div>
                  <h3 className="text-xl font-bold mb-2 group-hover:text-accent transition-colors">Admin Dashboard</h3>
                  <p className="text-muted-foreground">Manage students, issue bills, and verify payment receipts.</p>
                  <div className="absolute bottom-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity transform translate-x-2 group-hover:translate-x-0">
                    <ArrowRight className="w-6 h-6 text-accent" />
                  </div>
                </div>
              </Link>
            ) : (
              <div className="bg-card/50 border border-dashed rounded-2xl p-8 text-center flex flex-col items-center justify-center opacity-60 grayscale">
                <ShieldCheck className="w-12 h-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-bold mb-1">Admin Access Restricted</h3>
                <p className="text-sm text-muted-foreground">Only authorized staff can access this dashboard.</p>
              </div>
            )}
          </div>
          
          <Button variant="ghost" onClick={() => window.location.href = "/api/logout"} className="text-muted-foreground">
            Sign out
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <nav className="border-b bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary text-white flex items-center justify-center font-bold">I</div>
            <span className="font-display font-bold text-xl">Impacthouse College</span>
          </div>
          <Button onClick={() => window.location.href = "/api/login"} className="font-semibold shadow-lg shadow-primary/20 hover:shadow-primary/30">
            Log In
          </Button>
        </div>
      </nav>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-20 lg:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 -z-10" />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tight text-foreground mb-6">
              Impacthouse College <br className="hidden md:block" />
              <span className="text-gradient">Portal.</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
              A comprehensive portal for parents to track progress and payments, and for administrators to manage school operations efficiently.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" className="h-14 px-8 text-lg rounded-full shadow-xl shadow-primary/25 hover:scale-105 transition-transform" onClick={() => window.location.href = "/api/login"}>
                Get Started
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="py-20 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-card p-8 rounded-2xl border shadow-sm hover:shadow-md transition-all">
                <div className="h-12 w-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mb-6">
                  <Users className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-3">Parent Access</h3>
                <p className="text-muted-foreground">Secure login for parents to view student details and history.</p>
              </div>
              <div className="bg-card p-8 rounded-2xl border shadow-sm hover:shadow-md transition-all">
                <div className="h-12 w-12 bg-green-100 text-green-600 rounded-xl flex items-center justify-center mb-6">
                  <CreditCard className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-3">Easy Payments</h3>
                <p className="text-muted-foreground">View pending bills and upload payment receipts instantly.</p>
              </div>
              <div className="bg-card p-8 rounded-2xl border shadow-sm hover:shadow-md transition-all">
                <div className="h-12 w-12 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center mb-6">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-3">Admin Control</h3>
                <p className="text-muted-foreground">Manage students, issue bills, and verify payments in one place.</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-12 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Impacthouse College School Portal. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
