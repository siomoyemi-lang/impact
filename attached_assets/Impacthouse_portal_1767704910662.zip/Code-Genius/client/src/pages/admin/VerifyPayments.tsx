import { DashboardLayout } from "@/components/DashboardLayout";
import { usePendingPayments, useVerifyPayment } from "@/hooks/use-payments";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Check, X, ExternalLink, Calendar, DollarSign } from "lucide-react";
import { format } from "date-fns";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";

export default function VerifyPayments() {
  const { data: payments, isLoading } = usePendingPayments();
  const { mutate: verifyPayment, isPending } = useVerifyPayment();

  const handleVerify = (id: number, status: "verified" | "rejected") => {
    verifyPayment({ id, status });
  };

  return (
    <DashboardLayout role="admin">
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold">Verify Payments</h1>
        <p className="text-muted-foreground mt-1">Review and approve pending payment receipts.</p>
      </div>

      {isLoading ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-80 bg-muted/20 animate-pulse rounded-2xl" />
          ))}
        </div>
      ) : payments?.length === 0 ? (
        <div className="text-center py-20 bg-card rounded-3xl border border-dashed">
          <div className="h-16 w-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold">All caught up!</h3>
          <p className="text-muted-foreground max-w-sm mx-auto mt-2">
            There are no pending payments to verify at the moment.
          </p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {payments?.map((payment) => (
            <Card key={payment.id} className="overflow-hidden border-border/50 shadow-md">
              <div className="aspect-video bg-muted relative group">
                {payment.receiptUrl ? (
                  <>
                    <img 
                      src={`/objects/${payment.receiptUrl.replace(/^\/objects\//, '')}`} 
                      alt="Receipt" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                       <Dialog>
                         <DialogTrigger asChild>
                           <Button variant="secondary" size="sm" className="gap-2">
                             <ExternalLink className="w-4 h-4" /> View Full
                           </Button>
                         </DialogTrigger>
                         <DialogContent className="max-w-4xl p-0 overflow-hidden bg-transparent border-none shadow-none">
                           <img 
                             src={`/objects/${payment.receiptUrl.replace(/^\/objects\//, '')}`} 
                             alt="Receipt Full" 
                             className="w-full h-auto rounded-lg"
                           />
                         </DialogContent>
                       </Dialog>
                    </div>
                  </>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    No image
                  </div>
                )}
              </div>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg flex items-center gap-1">
                      <DollarSign className="w-4 h-4 text-primary" />
                      {(payment.amount / 100).toFixed(2)}
                    </CardTitle>
                    <CardDescription>Bill ID: #{payment.billId}</CardDescription>
                  </div>
                  <div className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                    {payment.createdAt ? format(new Date(payment.createdAt), 'MMM d') : 'N/A'}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pb-4">
                <p className="text-sm text-muted-foreground bg-muted/30 p-2 rounded border border-border/50">
                  {payment.notes || "No notes provided"}
                </p>
              </CardContent>
              <CardFooter className="gap-2 pt-0">
                <Button 
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white" 
                  onClick={() => handleVerify(payment.id, "verified")}
                  disabled={isPending}
                >
                  <Check className="w-4 h-4 mr-2" /> Verify
                </Button>
                <Button 
                  className="flex-1" 
                  variant="destructive"
                  onClick={() => handleVerify(payment.id, "rejected")}
                  disabled={isPending}
                >
                  <X className="w-4 h-4 mr-2" /> Reject
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
