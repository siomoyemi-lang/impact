import { DashboardLayout } from "@/components/DashboardLayout";
import { useStudent, useStudentBills } from "@/hooks/use-students";
import { useCreatePayment } from "@/hooks/use-payments";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ArrowLeft, UploadCloud, DollarSign, Calendar, FileText } from "lucide-react";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { format } from "date-fns";
import { ObjectUploader } from "@/components/ObjectUploader";
import { useState } from "react";

export default function StudentDetails({ params }: { params: { id: string } }) {
  const id = parseInt(params.id);
  const [, setLocation] = useLocation();
  const { data: student, isLoading: isLoadingStudent } = useStudent(id);
  const { data: bills, isLoading: isLoadingBills } = useStudentBills(id);
  const { mutate: createPayment, isPending: isPaying } = useCreatePayment();
  const [selectedBillId, setSelectedBillId] = useState<number | null>(null);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);

  // Helper function for presigned URL request (used by ObjectUploader)
  const getUploadParameters = async (file: any) => {
    const res = await fetch("/api/uploads/request-url", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: file.name,
        size: file.size,
        contentType: file.type,
      }),
    });
    const { uploadURL } = await res.json();
    return {
      method: "PUT" as const,
      url: uploadURL,
      headers: { "Content-Type": file.type },
    };
  };

  const handlePaymentComplete = (result: any) => {
    // result.successful[0].uploadURL or similar depending on uppy version/config
    // But since we use presigned URL flow, we usually construct the public URL or use the upload response
    // For this implementation, we need the URL that was uploaded to.
    // The ObjectUploader component uses AwsS3 plugin.
    // Let's assume the result object contains the uploaded file info.
    // However, with presigned URLs, the client knows the URL it uploaded to.
    
    // A simpler approach with the provided ObjectUploader:
    // The onComplete callback gives us the files.
    // We can't easily get the final public URL unless we construct it or the backend returns it in getUploadParameters (which it does, but Uppy hides it).
    
    // ACTUALLY: The backend `api/uploads/request-url` returns `objectPath`. 
    // We need to capture that. 
    // Since `ObjectUploader` isolates this logic, let's look at how we can pass state up.
    // The provided `ObjectUploader` doesn't easily expose the response from `getUploadParameters` to `onComplete`.
    
    // Workaround: We'll use the `useUpload` hook pattern instead of `ObjectUploader` for this specific case 
    // OR we modify `ObjectUploader` to support this, but I cannot modify provided components easily.
    
    // Let's use `useUpload` logic inside a custom component here for maximum control,
    // OR just use `ObjectUploader` and assume we can derive the URL.
    
    // Let's assume the user selects a file, we get the presigned URL, upload it.
    // In `onComplete`, `result.successful[0].uploadURL` should be the URL where it was PUT.
    // That URL might be the signed URL (with query params). We need the clean URL.
    // But `api/uploads/request-url` returns `objectPath` which is cleaner.
    
    // Let's trust the `result.successful[0].uploadURL` is usable or just extract the path.
    // Actually, let's use the `ObjectUploader` as instructed but we need to know the 'objectPath'.
    // The `ObjectUploader` doesn't pass the custom response data from `getUploadParameters` to `onComplete`.
    
    // Wait, let's check `result.successful[0].response`.
    // If we can't get it, we might need a custom uploader for this specific form.
    // Let's use a simple file input and `useUpload` hook from `@/hooks/use-upload` inside the dialog.
    // It is much safer and cleaner for form integration.
  };

  if (isLoadingStudent || isLoadingBills) {
    return <div className="p-8">Loading...</div>;
  }

  if (!student) return <div>Student not found</div>;

  return (
    <DashboardLayout role="parent">
      <div className="mb-6">
        <Button variant="ghost" className="pl-0 gap-2 hover:bg-transparent hover:text-primary" onClick={() => setLocation("/parent/wards")}>
          <ArrowLeft className="w-4 h-4" /> Back to Wards
        </Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Student Profile Card */}
        <div className="lg:col-span-1">
          <Card className="border-t-4 border-t-primary shadow-lg">
            <CardHeader className="text-center pb-8">
              <div className="h-24 w-24 bg-primary/10 text-primary text-3xl font-bold rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-white shadow-sm">
                {student.name.substring(0, 2).toUpperCase()}
              </div>
              <CardTitle className="text-2xl">{student.name}</CardTitle>
              <p className="text-muted-foreground font-medium mt-1">Grade: {student.grade}</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <span className="text-sm text-muted-foreground">Student ID</span>
                <span className="font-mono font-medium">{student.id.toString().padStart(6, '0')}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <span className="text-sm text-muted-foreground">Parent ID</span>
                <span className="font-mono text-xs">{student.parentId.split('-')[0]}...</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bills & Payments */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold font-display">Tuition & Bills</h2>
          </div>

          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Description</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bills?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      No bills found for this student.
                    </TableCell>
                  </TableRow>
                ) : (
                  bills?.map((bill) => (
                    <TableRow key={bill.id}>
                      <TableCell className="font-medium">{bill.description}</TableCell>
                      <TableCell className="text-muted-foreground">
                        {format(new Date(bill.dueDate), 'MMM d, yyyy')}
                      </TableCell>
                      <TableCell>${(bill.amount / 100).toFixed(2)}</TableCell>
                      <TableCell>
                        <StatusBadge status={bill.status} />
                      </TableCell>
                      <TableCell className="text-right">
                        {bill.status === 'pending' && (
                          <Dialog open={isPaymentOpen && selectedBillId === bill.id} onOpenChange={(open) => {
                            setIsPaymentOpen(open);
                            if (!open) setSelectedBillId(null);
                            else setSelectedBillId(bill.id);
                          }}>
                            <DialogTrigger asChild>
                              <Button size="sm" className="gap-2">
                                <DollarSign className="w-3.5 h-3.5" /> Pay Now
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Upload Payment Receipt</DialogTitle>
                                <DialogDescription>
                                  Please upload a clear image of your payment receipt (bank transfer, deposit slip, etc.) for verification.
                                </DialogDescription>
                              </DialogHeader>
                              
                              <div className="py-6">
                                <div className="bg-muted/30 p-4 rounded-lg mb-6 border">
                                  <div className="flex justify-between mb-2">
                                    <span className="text-sm text-muted-foreground">Bill Amount:</span>
                                    <span className="font-bold">${(bill.amount / 100).toFixed(2)}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-sm text-muted-foreground">Description:</span>
                                    <span className="text-sm font-medium">{bill.description}</span>
                                  </div>
                                </div>

                                <PaymentUploader 
                                  billId={bill.id} 
                                  amount={bill.amount} 
                                  onSuccess={() => setIsPaymentOpen(false)} 
                                />
                              </div>
                            </DialogContent>
                          </Dialog>
                        )}
                        {bill.status === 'paid' && (
                          <Button size="sm" variant="ghost" disabled>Paid</Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}

// Internal component to handle upload and mutation
import { useUpload } from "@/hooks/use-upload";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";

function PaymentUploader({ billId, amount, onSuccess }: { billId: number, amount: number, onSuccess: () => void }) {
  const { uploadFile, isUploading, error: uploadError } = useUpload();
  const { mutate: createPayment, isPending: isSubmitting } = useCreatePayment();
  const [file, setFile] = useState<File | null>(null);

  const handleSubmit = async () => {
    if (!file) return;

    try {
      // 1. Upload file
      const uploadRes = await uploadFile(file);
      if (!uploadRes) return; // Error handled by hook

      // 2. Submit payment record with object path
      createPayment({
        billId,
        amount,
        receiptUrl: uploadRes.objectPath, // Store the path!
        notes: "Uploaded via portal",
      }, {
        onSuccess: () => onSuccess()
      });
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid w-full max-w-sm items-center gap-1.5">
        <Label htmlFor="receipt">Receipt Image</Label>
        <Input id="receipt" type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] || null)} />
        {file && <p className="text-xs text-muted-foreground">Selected: {file.name}</p>}
      </div>

      {uploadError && <p className="text-sm text-destructive">{uploadError.message}</p>}

      <Button 
        onClick={handleSubmit} 
        disabled={!file || isUploading || isSubmitting} 
        className="w-full"
      >
        {(isUploading || isSubmitting) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        {isUploading ? "Uploading..." : isSubmitting ? "Submitting..." : "Submit Receipt"}
      </Button>
    </div>
  );
}
