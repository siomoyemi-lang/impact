import { DashboardLayout } from "@/components/DashboardLayout";
import { useStudents } from "@/hooks/use-students";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ArrowRight, GraduationCap } from "lucide-react";
import { format } from "date-fns";

export default function WardsList() {
  const { data: students, isLoading } = useStudents();

  return (
    <DashboardLayout role="parent">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold">My Wards</h1>
          <p className="text-muted-foreground mt-1">Select a student to view details and bills.</p>
        </div>
      </div>

      {isLoading ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-64 bg-muted/20 animate-pulse rounded-2xl" />
          ))}
        </div>
      ) : students?.length === 0 ? (
        <div className="text-center py-20 bg-card rounded-3xl border border-dashed">
          <div className="h-16 w-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <GraduationCap className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold">No students found</h3>
          <p className="text-muted-foreground max-w-sm mx-auto mt-2">
            You don't have any wards linked to your account yet. Please contact the school administration.
          </p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {students?.map((student) => (
            <Card key={student.id} className="hover-lift overflow-hidden border-border/50">
              <div className="h-2 bg-gradient-to-r from-primary to-accent" />
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <Avatar className="h-16 w-16 border-4 border-background shadow-lg">
                    <AvatarFallback className="bg-primary/10 text-primary text-xl font-bold">
                      {student.name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="px-3 py-1 bg-muted rounded-full text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Active
                  </div>
                </div>
                <div className="mt-4">
                  <CardTitle className="text-xl">{student.name}</CardTitle>
                  <CardDescription className="flex items-center gap-2 mt-1">
                    <GraduationCap className="w-4 h-4" />
                    Grade: {student.grade}
                  </CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-sm text-muted-foreground">
                    Joined: {format(new Date(student.createdAt!), 'MMM d, yyyy')}
                  </div>
                  <Link href={`/parent/student/${student.id}`}>
                    <Button className="w-full group">
                      View Details
                      <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
