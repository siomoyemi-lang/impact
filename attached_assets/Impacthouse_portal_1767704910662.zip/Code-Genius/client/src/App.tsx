import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

// Pages
import Landing from "@/pages/Landing";
// Parent Routes
import WardsList from "@/pages/parent/WardsList";
import StudentDetails from "@/pages/parent/StudentDetails";
// Admin Routes
import ManageStudents from "@/pages/admin/ManageStudents";
import IssueBills from "@/pages/admin/IssueBills";
import VerifyPayments from "@/pages/admin/VerifyPayments";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      
      {/* Parent Dashboard */}
      <Route path="/parent/wards" component={WardsList} />
      <Route path="/parent/student/:id" component={StudentDetails} />
      
      {/* Admin Dashboard */}
      <Route path="/admin/students" component={ManageStudents} />
      <Route path="/admin/bills" component={IssueBills} />
      <Route path="/admin/payments" component={VerifyPayments} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
