# School Portal

## Overview

A full-stack school portal application for managing students, bills, and payments. The system supports two user roles: **Parents** (who view their wards and make payments) and **Admins** (who manage students, issue bills, and verify payments). Built with React frontend, Express backend, PostgreSQL database, and Replit Auth for authentication.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state caching and synchronization
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and CSS variables
- **Build Tool**: Vite with HMR support

The frontend follows a pages-based structure with role-specific dashboards:
- `/parent/*` routes for parent functionality (view wards, bills, submit payments)
- `/admin/*` routes for admin functionality (manage students, issue bills, verify payments)

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful endpoints defined in `shared/routes.ts` with Zod schema validation
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Session Management**: Express sessions with PostgreSQL session store (connect-pg-simple)

The backend uses a storage pattern (`server/storage.ts`) that abstracts database operations, making it easy to swap implementations.

### Database Design
- **PostgreSQL** with Drizzle ORM
- **Schema** defined in `shared/schema.ts` with the following tables:
  - `users` - User accounts (managed by Replit Auth)
  - `sessions` - Session storage for authentication
  - `students` - Student records linked to parent users
  - `bills` - Bills issued to students with amount, due date, and status
  - `payments` - Payment records with receipt uploads and verification status

### Authentication
- **Replit Auth** integration using OpenID Connect
- Session-based authentication with PostgreSQL session store
- Role determination based on email (admin emails hardcoded for demo purposes)

### File Upload System
- **Uppy** for client-side file handling with dashboard modal
- **Google Cloud Storage** integration via presigned URLs
- Two-step upload flow: request presigned URL from backend, then upload directly to storage

### Shared Code
The `shared/` directory contains code used by both frontend and backend:
- `schema.ts` - Drizzle database schemas and Zod validation schemas
- `routes.ts` - API contract definitions with path, method, and response schemas
- `models/auth.ts` - User and session table definitions

## External Dependencies

### Database
- **PostgreSQL** - Primary database (connection via `DATABASE_URL` environment variable)
- **Drizzle Kit** - Database migrations and schema push (`npm run db:push`)

### Authentication
- **Replit Auth** - OAuth2/OpenID Connect provider
- Required environment variables: `ISSUER_URL`, `REPL_ID`, `SESSION_SECRET`

### File Storage
- **Google Cloud Storage** - Object storage for payment receipts
- Accessed via Replit sidecar endpoint at `http://127.0.0.1:1106`
- Environment variable: `PUBLIC_OBJECT_SEARCH_PATHS` for public object paths

### Key NPM Packages
- `@tanstack/react-query` - Data fetching and caching
- `drizzle-orm` / `drizzle-zod` - ORM and schema validation
- `@uppy/core` / `@uppy/aws-s3` - File upload handling
- `passport` / `openid-client` - Authentication
- `zod` - Runtime type validation