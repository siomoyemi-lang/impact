import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, User, GraduationCap, FileText, Receipt, PlusCircle } from "lucide-react";
import { useLocation } from "wouter";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export function GlobalSearch() {
  const [open, setOpen] = React.useState(false);
  const [, setLocation] = useLocation();

  React.useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };
    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  const { data: students } = useQuery<any[]>({
    queryKey: ["/api/admin/students"],
    enabled: open,
  });

  const { data: users } = useQuery<any[]>({
    queryKey: ["/api/admin/users/role/ADMIN"],
    enabled: open,
  });

  const onSelect = (path: string) => {
    // If we're already on the billing page and trying to navigate to it with new params,
    // wouter's setLocation might not trigger a state update for the search params.
    // We force a refresh of the search params by using window.history if needed, 
    // but better to just use setLocation and ensure the billing page listens to 'location'.
    setLocation(path);
    setOpen(false);
  };

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 px-3 py-1.5 text-sm text-slate-500 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors w-64 border border-slate-200"
      >
        <Search className="w-4 h-4" />
        <span className="flex-1 text-left">Search...</span>
        <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground opacity-100">
          <span className="text-xs">⌘</span>K
        </kbd>
      </button>

      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder="Type to search students or staff..." />
        <CommandList className="max-h-[450px]">
          <CommandEmpty>No results found.</CommandEmpty>
          
          <CommandGroup heading="Quick Actions">
            <CommandItem onSelect={() => onSelect("/admin/students")}>
              <GraduationCap className="mr-2 h-4 w-4" />
              <span>Go to Student Directory</span>
            </CommandItem>
            <CommandItem onSelect={() => onSelect("/admin/billing")}>
              <FileText className="mr-2 h-4 w-4" />
              <span>View Billing Overview</span>
            </CommandItem>
          </CommandGroup>

          <CommandSeparator />

          {students && students.length > 0 && (
            <CommandGroup heading="Students">
              {students.slice(0, 5).map((student) => {
                const names = student.fullName.split(' ');
                const initials = names.map((n: string) => n[0]).join('').toUpperCase();
                return (
                  <div key={student.id} className="px-2">
                    <CommandItem
                      onSelect={() => onSelect(`/admin/students?id=${student.id}`)}
                      className="flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-xs">
                          {initials}
                        </div>
                        <div>
                          <div className="font-medium">{student.fullName}</div>
                          <div className="text-xs text-slate-500">Grade: {student.className} • ID: {student.admissionNumber}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-[10px]"
                          onClick={() => onSelect(`/admin/billing?studentId=${student.id}&action=create`)}
                        >
                          <PlusCircle className="w-3 h-3 mr-1" />
                          Bill
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-[10px]"
                          onClick={() => onSelect(`/admin/receipts?studentId=${student.id}`)}
                        >
                          <Receipt className="w-3 h-3 mr-1" />
                          Receipts
                        </Button>
                      </div>
                    </CommandItem>
                  </div>
                );
              })}
            </CommandGroup>
          )}

          <CommandSeparator />

          {users && users.length > 0 && (
            <CommandGroup heading="Administrators">
              {users.slice(0, 3).map((admin) => (
                <CommandItem
                  key={admin.id}
                  onSelect={() => onSelect("/admin/users")}
                  className="flex items-center gap-2"
                >
                  <User className="w-4 h-4 text-slate-400" />
                  <div>
                    <div className="font-medium">{admin.email}</div>
                    <div className="text-xs text-slate-500">Administrator</div>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          )}
        </CommandList>
      </CommandDialog>
    </>
  );
}
