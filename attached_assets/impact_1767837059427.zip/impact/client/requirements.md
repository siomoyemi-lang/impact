## Packages
framer-motion | For smooth page transitions and entry animations
recharts | For dashboard analytics charts (if we add visualizations)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
